export interface Quote {
  id?: string;
  cn: string;
  en: string;
  pic: string;
}
